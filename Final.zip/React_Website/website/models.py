products_list = {
        1: {
            "name": "Laptop",
            "img": "laptop.jpg",
            "title": "Microsoft Surface Laptop 4 AMD Ryzen 5 4680U 13.5 inches Touchscreen Laptop"
        },
        2: {
            "name": "Television",
            "img": "tv_img.jpg",
            "title": "Croma Fire TV 80cm (32 Inch) HD Ready LED Smart TV (3 Years Warranty, Alexa Voice Assistant Remote, CREL7364, Black)"
        },
        3: {
            "name": "VR Headset",
            "img": "vr_img.jpg",
            "title": "VR Headset Compatible with iPhone & Android Phone - Universal Virtual Reality Goggles - Soft & Comfortable New 3D VR Glasses (Blue)"
        },
        4: {
            "name": "Car",
            "img": "car_img.jpg",
            "title": "2021 MG Hector CVT launched at Rs 16.52 Lakh"
        },
        5: {
            "name": "Shoes",
            "img": "shoes_img.jpg",
            "title": "Elegant Black Leather Shoes stock photoShoe, Men, Cut Out, Leather, White Background"
        },
        6: {
            "name": "Sun Glasses",
            "img": "glasses_img.jpg",
            "title": "GREY JACK Polarized Aviator Sunglasses lightweight Stylish Glasses for Men Women UV Protection S110102"
        }
    }
  
empty_cart={}
for key,value in products_list.items():
    empty_cart[key]={
        'name':value['name']
        ,
        'quantity':0
    }
